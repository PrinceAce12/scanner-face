"use client";

import dynamic from 'next/dynamic';

const FaceScanner = dynamic(() => import('@/components/FaceScanner'), {
  ssr: false,
});

export default function Home() {
  return <FaceScanner />;
}
