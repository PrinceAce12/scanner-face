"use client";

import React, { useState, useRef, useCallback, useEffect } from 'react';
import Webcam from 'react-webcam';
import { Camera, UserPlus, CheckCircle, Loader2, RefreshCw, AlertCircle } from 'lucide-react';
import * as faceapi from '@vladmandic/face-api';

const MODEL_URL = 'https://cdn.jsdelivr.net/npm/@vladmandic/face-api/model/';

export default function FaceScanner() {
  const webcamRef = useRef<Webcam>(null);
  const [isModelLoaded, setIsModelLoaded] = useState(false);
  const [imageSrc, setImageSrc] = useState<string | null>(null);
  const [status, setStatus] = useState<'idle' | 'scanning' | 'recognized' | 'not_found' | 'registering'>('idle');
  const [name, setName] = useState<string>('');
  const [recognizedName, setRecognizedName] = useState<string>('');
  const [error, setError] = useState<string | null>(null);

  // Load models on mount
  useEffect(() => {
    const loadModels = async () => {
      try {
        await Promise.all([
          faceapi.nets.ssdMobilenetv1.loadFromUri(MODEL_URL),
          faceapi.nets.faceLandmark68Net.loadFromUri(MODEL_URL),
          faceapi.nets.faceRecognitionNet.loadFromUri(MODEL_URL)
        ]);
        setIsModelLoaded(true);
      } catch (err) {
        console.error("Failed to load models", err);
        setError("Failed to load AI models. Please check your internet connection.");
      }
    };
    loadModels();
  }, []);

  // Helper to convert base64 to an HTMLImageElement
  const getHtmlImage = (base64Str: string): Promise<HTMLImageElement> => {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = reject;
      img.src = base64Str;
    });
  };

  const handleScan = async (image: string) => {
    setStatus('scanning');
    setError(null);
    
    try {
      const imgElement = await getHtmlImage(image);
      const detection = await faceapi.detectSingleFace(imgElement).withFaceLandmarks().withFaceDescriptor();
      
      if (!detection) {
        setError('No face detected. Please ensure your face is clearly visible.');
        setStatus('idle');
        setImageSrc(null);
        return;
      }

      // Fetch saved faces from localStorage
      const savedFacesStr = localStorage.getItem('registered_faces');
      if (!savedFacesStr) {
        setStatus('not_found');
        return;
      }

      const savedFaces: { name: string, descriptor: number[] }[] = JSON.parse(savedFacesStr);
      
      let bestMatchName = null;
      let bestDistance = 0.6; // 0.6 is the standard threshold for face-api.js (lower is better)

      for (const face of savedFaces) {
        // Convert the saved number array back to a Float32Array
        const savedDescriptor = new Float32Array(face.descriptor);
        const distance = faceapi.euclideanDistance(detection.descriptor, savedDescriptor);
        
        if (distance < bestDistance) {
          bestDistance = distance;
          bestMatchName = face.name;
        }
      }
      
      if (bestMatchName) {
        setRecognizedName(bestMatchName);
        setStatus('recognized');
      } else {
        setStatus('not_found');
      }
    } catch (err) {
      console.error(err);
      setError('An error occurred during scanning.');
      setStatus('idle');
    }
  };

  const capture = () => {
    const image = webcamRef.current?.getScreenshot();
    if (image) {
      setImageSrc(image);
      handleScan(image);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !imageSrc) return;
    
    setStatus('registering');
    setError(null);
    
    try {
      const imgElement = await getHtmlImage(imageSrc);
      const detection = await faceapi.detectSingleFace(imgElement).withFaceLandmarks().withFaceDescriptor();
      
      if (!detection) {
        setError('No face detected. Please try scanning again.');
        setStatus('not_found');
        return;
      }

      // Save to localStorage
      const savedFacesStr = localStorage.getItem('registered_faces');
      const savedFaces = savedFacesStr ? JSON.parse(savedFacesStr) : [];
      
      // Convert Float32Array to standard array for JSON serialization
      savedFaces.push({
        name: name.trim(),
        descriptor: Array.from(detection.descriptor)
      });
      
      localStorage.setItem('registered_faces', JSON.stringify(savedFaces));
      
      setRecognizedName(name.trim());
      setStatus('recognized');
    } catch (err) {
      console.error(err);
      setError('Failed to register face.');
      setStatus('not_found');
    }
  };

  const reset = () => {
    setImageSrc(null);
    setStatus('idle');
    setName('');
    setRecognizedName('');
    setError(null);
  };

  if (!isModelLoaded) {
    return (
      <div className="min-h-screen bg-zinc-950 text-zinc-50 flex flex-col items-center justify-center p-4 font-sans">
        <Loader2 className="w-12 h-12 text-indigo-500 animate-spin mb-4" />
        <h2 className="text-xl font-medium">Loading AI Models...</h2>
        <p className="text-zinc-500 text-sm mt-2">Downloading face recognition weights (~5MB)</p>
      </div>
    );
  }

  return (
    <main className="min-h-screen bg-zinc-950 text-zinc-50 flex flex-col items-center justify-center p-4 font-sans">
      <div className="max-w-md w-full bg-zinc-900 border border-zinc-800 rounded-2xl shadow-2xl overflow-hidden">
        <div className="p-6 text-center border-b border-zinc-800">
          <h1 className="text-2xl font-semibold tracking-tight">Face ID</h1>
          <p className="text-zinc-400 text-sm mt-1">100% Client-Side Facial Recognition</p>
        </div>

        <div className="p-6 flex flex-col items-center space-y-6">
          {/* Camera / Image Area */}
          <div className="relative w-full aspect-square rounded-xl overflow-hidden bg-zinc-950 border border-zinc-800 flex items-center justify-center">
            {!imageSrc ? (
              <Webcam
                audio={false}
                ref={webcamRef}
                screenshotFormat="image/jpeg"
                videoConstraints={{ facingMode: "user" }}
                className="w-full h-full object-cover"
              />
            ) : (
              <img src={imageSrc} alt="Captured" className="w-full h-full object-cover" />
            )}

            {/* Scanning Overlay */}
            {status === 'scanning' && (
              <div className="absolute inset-0 bg-black/60 flex flex-col items-center justify-center backdrop-blur-sm">
                <Loader2 className="w-10 h-10 text-emerald-500 animate-spin mb-3" />
                <p className="text-emerald-500 font-medium tracking-wide animate-pulse">Analyzing face...</p>
              </div>
            )}
            
            {/* Registering Overlay */}
            {status === 'registering' && (
              <div className="absolute inset-0 bg-black/60 flex flex-col items-center justify-center backdrop-blur-sm">
                <Loader2 className="w-10 h-10 text-indigo-500 animate-spin mb-3" />
                <p className="text-indigo-500 font-medium tracking-wide animate-pulse">Saving profile...</p>
              </div>
            )}
          </div>

          {/* Error Message */}
          {error && (
            <div className="w-full p-3 bg-red-500/10 border border-red-500/20 rounded-lg text-red-400 text-sm text-center flex items-center justify-center gap-2">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Controls Area */}
          <div className="w-full">
            {status === 'idle' && (
              <button
                onClick={capture}
                className="w-full py-3 px-4 bg-white text-black font-medium rounded-xl hover:bg-zinc-200 transition-colors flex items-center justify-center gap-2"
              >
                <Camera className="w-5 h-5" />
                Scan Face
              </button>
            )}

            {status === 'recognized' && (
              <div className="flex flex-col items-center space-y-4 w-full animate-in fade-in slide-in-from-bottom-4 duration-500">
                <div className="flex items-center gap-2 text-emerald-400 bg-emerald-400/10 px-4 py-2 rounded-full border border-emerald-400/20">
                  <CheckCircle className="w-5 h-5" />
                  <span className="font-medium">Welcome back, {recognizedName}!</span>
                </div>
                <button
                  onClick={reset}
                  className="w-full py-3 px-4 bg-zinc-800 text-zinc-200 font-medium rounded-xl hover:bg-zinc-700 transition-colors flex items-center justify-center gap-2"
                >
                  <RefreshCw className="w-4 h-4" />
                  Scan Again
                </button>
              </div>
            )}

            {status === 'not_found' && (
              <form onSubmit={handleRegister} className="w-full space-y-3 animate-in fade-in slide-in-from-bottom-4 duration-500">
                <div className="text-center mb-4">
                  <p className="text-zinc-300 font-medium">Face not recognized</p>
                  <p className="text-zinc-500 text-sm">Please register to continue</p>
                </div>
                <input
                  type="text"
                  placeholder="Enter your name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-4 py-3 bg-zinc-950 border border-zinc-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent text-zinc-100 placeholder:text-zinc-600"
                  required
                />
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={reset}
                    className="flex-1 py-3 px-4 bg-zinc-800 text-zinc-300 font-medium rounded-xl hover:bg-zinc-700 transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={!name.trim()}
                    className="flex-1 py-3 px-4 bg-indigo-600 text-white font-medium rounded-xl hover:bg-indigo-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                  >
                    <UserPlus className="w-4 h-4" />
                    Register
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      </div>
    </main>
  );
}
